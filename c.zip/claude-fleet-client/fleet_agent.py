#!/usr/bin/env python3
"""
claude-fleet agent - runs on each child machine.

Standard library only (Python 3.8+). Connects *out* to the hub over HTTP(S)
long-polling, so the child needs no open ports and works behind NAT/firewalls.

State (kept outside the repo, so re-cloning doesn't change identity):
  Linux/macOS: ~/.claude-fleet/      Windows: %USERPROFILE%\\.claude-fleet\\
    config.json    hub URL, token, optional requested name
    identity.json  permanent machine id (generated once)

Commands:
  fleet_agent.py configure HUB_URL TOKEN [--name NAME]
  fleet_agent.py check        verify hub is reachable and token works
  fleet_agent.py run          run the agent in the foreground (what the service runs)
  fleet_agent.py status       show identity and config
  fleet_agent.py watch        follow the activity log live (every command received/finished)
"""

import argparse
import base64
import codecs
import fnmatch
import getpass
import hashlib
import json
import os
import platform
import shutil
import signal
import socket
import ssl
import subprocess
import sys
import tarfile
import tempfile
import threading
import time
import urllib.error
import urllib.request
import uuid

VERSION = "1.4.0"
AGENT_DIR = os.path.dirname(os.path.abspath(__file__))
STATE = os.environ.get("FLEET_STATE_DIR", os.path.join(os.path.expanduser("~"), ".claude-fleet"))
CONFIG = os.path.join(STATE, "config.json")
IDENTITY = os.path.join(STATE, "identity.json")
WINDOWS = os.name == "nt"


LOG_FILE = os.path.join(STATE, "agent.log")
LOG_MAX = 5 * 1024 * 1024
_log_lock = threading.Lock()


def log(msg):
    """Print to the console (if there is one) and append to ~/.claude-fleet/agent.log."""
    line = "[%s] %s" % (time.strftime("%Y-%m-%d %H:%M:%S"), msg)
    with _log_lock:
        try:
            if sys.stdout is not None:      # None under pythonw (no console)
                print(line, flush=True)
        except Exception:
            pass
        try:
            os.makedirs(STATE, exist_ok=True)
            if os.path.exists(LOG_FILE) and os.path.getsize(LOG_FILE) > LOG_MAX:
                os.replace(LOG_FILE, LOG_FILE + ".1")
            with open(LOG_FILE, "a", encoding="utf-8") as f:
                f.write(line + "\n")
        except Exception:
            pass


def short(text, n=200):
    text = " ".join(str(text).split())
    return text if len(text) <= n else text[: n - 3] + "..."


def watch(lines=30):
    """Follow agent.log in this terminal (like tail -f), surviving log rotation."""
    print("Following %s  (Ctrl+C to stop)\n" % LOG_FILE, flush=True)
    while not os.path.exists(LOG_FILE):
        time.sleep(1)
    f = open(LOG_FILE, "r", encoding="utf-8", errors="replace")
    for line in f.readlines()[-lines:]:
        sys.stdout.write(line)
    sys.stdout.flush()
    try:
        while True:
            line = f.readline()
            if line:
                sys.stdout.write(line)
                sys.stdout.flush()
                continue
            time.sleep(0.5)
            try:
                size = os.path.getsize(LOG_FILE)
            except OSError:
                continue
            if size < f.tell():             # rotated
                f.close()
                f = open(LOG_FILE, "r", encoding="utf-8", errors="replace")
    except KeyboardInterrupt:
        pass


def excluded(name, patterns):
    return any(fnmatch.fnmatch(part, pat) for part in name.replace("\\", "/").split("/")
               for pat in patterns)


def safe_extract(tar_path, dest):
    with tarfile.open(tar_path, "r:*") as tar:
        try:
            tar.extractall(dest, filter="data")
            return
        except TypeError:
            pass  # Python without extraction filters
        root = os.path.realpath(dest)
        for m in tar.getmembers():
            target = os.path.realpath(os.path.join(dest, m.name))
            if not (target == root or target.startswith(root + os.sep)) or m.issym() or m.islnk():
                raise RuntimeError("unsafe archive member: %s" % m.name)
        tar.extractall(dest)


RESTART_PS1 = r"""param([string]$TaskName = "claude-fleet", [string]$AgentPath = "")
$ErrorActionPreference = "Continue"
$log = Join-Path $env:USERPROFILE ".claude-fleet\restart.log"
function L($m) { Add-Content -Path $log -Value ("[{0}] {1}" -f (Get-Date -Format s), $m) }
Start-Sleep -Seconds 3
L "restart helper started (task $TaskName)"
# only this user's agent from this folder - never anyone else's
$procs = Get-CimInstance Win32_Process | Where-Object {
  $_.CommandLine -and $_.CommandLine.IndexOf($AgentPath, [StringComparison]::OrdinalIgnoreCase) -ge 0 -and $_.CommandLine -match '\s+run\s*$' }
foreach ($p in $procs) { L ("stopping pid {0}" -f $p.ProcessId); Stop-Process -Id $p.ProcessId -Force -ErrorAction SilentlyContinue }
Stop-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
Start-Sleep -Seconds 2
Start-ScheduledTask -TaskName $TaskName
L ("task state after start: {0}" -f (Get-ScheduledTask -TaskName $TaskName).State)
"""


# --------------------------------------------------------------------------- #
# Keep-awake: stop the display/computer sleeping while jobs run (no admin needed)
# --------------------------------------------------------------------------- #

class KeepAwake:
    """While `active()` is true, ask the OS not to sleep the display or the computer.
    Windows: SetThreadExecutionState from one dedicated thread (the request is tied
    to that thread and is dropped automatically if the agent exits).
    macOS: a `caffeinate -di` child process. Other systems: no-op."""
    ES_CONTINUOUS, ES_SYSTEM_REQUIRED, ES_DISPLAY_REQUIRED = 0x80000000, 0x00000001, 0x00000002

    def __init__(self, active):
        self.active = active
        self.on = False
        self.proc = None
        self.supported = WINDOWS or (sys.platform == "darwin" and shutil.which("caffeinate"))

    def start(self):
        if self.supported:
            threading.Thread(target=self.loop, daemon=True).start()

    def _set(self, want):
        if WINDOWS:
            import ctypes
            flags = self.ES_CONTINUOUS
            if want:
                flags |= self.ES_SYSTEM_REQUIRED | self.ES_DISPLAY_REQUIRED
            if not ctypes.windll.kernel32.SetThreadExecutionState(flags):
                raise OSError("SetThreadExecutionState failed")
        else:
            if want and (self.proc is None or self.proc.poll() is not None):
                self.proc = subprocess.Popen(["caffeinate", "-di"])
            elif not want and self.proc is not None:
                self.proc.terminate()
                self.proc = None

    def loop(self):
        while True:
            try:
                want = bool(self.active())
                if want != self.on or (want and WINDOWS):   # re-assert periodically on Windows
                    self._set(want)
                    if want != self.on:
                        log("KEEP-AWAKE %s" % ("on (jobs running): display and computer won't sleep"
                                               if want else "off (idle): normal sleep allowed"))
                    self.on = want
            except Exception as e:
                log("KEEP-AWAKE unavailable: %s" % e)
                return
            time.sleep(10)


def read_json(path, default=None):
    try:
        with open(path) as f:
            return json.load(f)
    except (OSError, ValueError):
        return default


def write_json(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w") as f:
        json.dump(obj, f, indent=2)
    os.replace(tmp, path)
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass


# --------------------------------------------------------------------------- #
# Identity
# --------------------------------------------------------------------------- #

def hardware_id():
    """A stable OS-level machine identifier, if one is available."""
    try:
        if sys.platform.startswith("linux"):
            for p in ("/etc/machine-id", "/var/lib/dbus/machine-id"):
                if os.path.exists(p):
                    v = open(p).read().strip()
                    if v:
                        return v
        elif sys.platform == "darwin":
            out = subprocess.run(["ioreg", "-rd1", "-c", "IOPlatformExpertDevice"],
                                 capture_output=True, text=True, timeout=10).stdout
            for line in out.splitlines():
                if "IOPlatformUUID" in line:
                    return line.split('"')[-2]
        elif WINDOWS:
            import winreg  # noqa
            k = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography",
                               0, winreg.KEY_READ | winreg.KEY_WOW64_64KEY)
            return winreg.QueryValueEx(k, "MachineGuid")[0]
    except Exception:
        pass
    return ""


def fingerprint():
    hw = hardware_id()
    if not hw:
        return ""
    return hashlib.sha256(("claude-fleet|%s|%s" % (hw, getpass.getuser())).encode()).hexdigest()[:32]


def identity():
    ident = read_json(IDENTITY)
    if not ident or not ident.get("machine_id"):
        ident = {"machine_id": uuid.uuid4().hex, "created": time.time()}
        write_json(IDENTITY, ident)
    return ident


# --------------------------------------------------------------------------- #
# System info
# --------------------------------------------------------------------------- #

def memory():
    try:
        if sys.platform.startswith("linux"):
            for line in open("/proc/meminfo"):
                if line.startswith("MemTotal"):
                    return "%.1f GB" % (int(line.split()[1]) / 1024 / 1024)
        elif sys.platform == "darwin":
            b = int(subprocess.run(["sysctl", "-n", "hw.memsize"], capture_output=True,
                                   text=True, timeout=5).stdout)
            return "%.1f GB" % (b / 1024 ** 3)
        elif WINDOWS:
            import ctypes

            class MS(ctypes.Structure):
                _fields_ = [("l", ctypes.c_ulong), ("m", ctypes.c_ulong),
                            ("t", ctypes.c_ulonglong), ("a", ctypes.c_ulonglong),
                            ("tp", ctypes.c_ulonglong), ("ap", ctypes.c_ulonglong),
                            ("tv", ctypes.c_ulonglong), ("av", ctypes.c_ulonglong),
                            ("ae", ctypes.c_ulonglong)]
            ms = MS()
            ms.l = ctypes.sizeof(MS)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(ms))
            return "%.1f GB" % (ms.t / 1024 ** 3)
    except Exception:
        pass
    return "?"


def gpus():
    if shutil.which("nvidia-smi"):
        try:
            out = subprocess.run(
                ["nvidia-smi", "--query-gpu=name,memory.total", "--format=csv,noheader"],
                capture_output=True, text=True, timeout=10).stdout
            return [l.strip() for l in out.splitlines() if l.strip()]
        except Exception:
            pass
    if sys.platform == "darwin" and platform.machine() == "arm64":
        return ["Apple Silicon (Metal)"]
    return []


def os_release():
    if sys.platform.startswith("linux"):
        try:
            for line in open("/etc/os-release"):
                if line.startswith("PRETTY_NAME="):
                    return line.split("=", 1)[1].strip().strip('"')
        except OSError:
            pass
    if sys.platform == "darwin":
        return "macOS " + platform.mac_ver()[0]
    return platform.release()


def shell_argv(command):
    if WINDOWS:
        ps = shutil.which("pwsh") or shutil.which("powershell") or "powershell"
        return [ps, "-NoProfile", "-NonInteractive", "-Command", command]
    bash = shutil.which("bash")
    if bash:
        return [bash, "-lc", command]
    return ["/bin/sh", "-c", command]


def system_info():
    return {
        "hostname": socket.gethostname(),
        "os": platform.system(),
        "os_release": os_release(),
        "arch": platform.machine(),
        "cpus": os.cpu_count(),
        "memory": memory(),
        "gpus": gpus(),
        "python": platform.python_version(),
        "user": getpass.getuser(),
        "is_root": (not WINDOWS) and os.geteuid() == 0,
        "home": os.path.expanduser("~"),
        "shell": shell_argv("")[0],
        "agent_dir": AGENT_DIR,
        "agent_version": VERSION,
        "keep_awake": "while jobs run" if (WINDOWS or sys.platform == "darwin") else "unsupported",
    }


# --------------------------------------------------------------------------- #
# Hub client
# --------------------------------------------------------------------------- #

class HubError(Exception):
    def __init__(self, status, msg):
        super().__init__("%s %s" % (status, msg))
        self.status = status


class Client:
    def __init__(self, url, token):
        self.url = url.rstrip("/")
        self.token = token
        self.ctx = ssl.create_default_context()
        if os.environ.get("FLEET_INSECURE_TLS") == "1":   # self-signed hub cert
            self.ctx.check_hostname = False
            self.ctx.verify_mode = ssl.CERT_NONE

    def post(self, path, body, timeout=40):
        req = urllib.request.Request(
            self.url + path, data=json.dumps(body).encode(), method="POST",
            headers={"Content-Type": "application/json",
                     "Authorization": "Bearer " + self.token,
                     "User-Agent": "claude-fleet-agent/" + VERSION})
        try:
            with urllib.request.urlopen(req, timeout=timeout, context=self.ctx) as r:
                return json.loads(r.read() or b"{}")
        except urllib.error.HTTPError as e:
            raise HubError(e.code, e.read()[:200].decode(errors="replace"))


# --------------------------------------------------------------------------- #
# Agent
# --------------------------------------------------------------------------- #

class Agent:
    def __init__(self, cfg):
        self.cfg = cfg
        self.client = Client(cfg["hub"], cfg["token"])
        self.mid = identity()["machine_id"]
        self.name = None
        self.lock = threading.Lock()
        self.outbox = []            # events not yet acknowledged by hub
        self.seq = {}               # job -> last seq
        self.procs = {}             # job -> Popen
        self.kill_reason = {}
        self.wake = threading.Event()
        self.seen = []              # recent task ids (hub may redeliver until acked)
        self.stopping = False

    # ---- events ---- #
    def emit(self, ev):
        with self.lock:
            if "job" in ev:
                self.seq[ev["job"]] = self.seq.get(ev["job"], 0) + 1
                ev["seq"] = self.seq[ev["job"]]
            ev.setdefault("ts", time.time())
            # coalesce consecutive output chunks for the same job
            if (ev["type"] == "output" and self.outbox and self.outbox[-1]["type"] == "output"
                    and not self.outbox[-1].get("sealed")
                    and self.outbox[-1]["job"] == ev["job"] and len(self.outbox[-1]["data"]) < 200000):
                self.outbox[-1]["data"] += ev["data"]
                self.outbox[-1]["seq"] = ev["seq"]
            else:
                self.outbox.append(ev)
        if ev["type"] != "output":
            self.wake.set()

    def sender(self):
        backoff = 1
        while not self.stopping:
            self.wake.wait(0.5)
            self.wake.clear()
            with self.lock:
                # take the batch out of the outbox so nothing coalesces into it in flight
                batch, self.outbox = self.outbox[:200], self.outbox[200:]
            if not batch:
                continue
            try:
                self.client.post("/agent/events", {"machine_id": self.mid, "events": batch})
                backoff = 1
                if self.outbox:
                    self.wake.set()
            except Exception as e:
                with self.lock:
                    for b in batch:
                        b["sealed"] = True   # hub may have stored it; never grow it now
                    self.outbox = batch + self.outbox   # retry later, in order
                if isinstance(e, HubError) and e.status == 409:
                    self.hello()
                time.sleep(backoff)
                backoff = min(backoff * 2, 30)

    # ---- tasks ---- #
    def handle(self, task):
        t = task.get("type")
        if t == "exec":
            log("RECV  %s  %s%s" % (task["job"], short(task["command"]),
                                    "  (cwd %s)" % task["cwd"] if task.get("cwd") else ""))
        elif t == "kill":
            log("KILL  %s  requested by hub" % task.get("job"))
        elif t in ("read_file", "write_file"):
            log("%s  %s" % ("READ " if t == "read_file" else "WRITE", task.get("path")))
        elif t == "update":
            log("UPDATE requested by hub")
        elif t == "fetch":
            log("FETCH %s -> %s" % (task.get("name"), task.get("dest")))
        elif t == "upload":
            log("SEND  %s -> hub" % task.get("src"))
        elif t == "self_update":
            log("SELF-UPDATE requested by hub")
        try:
            if t == "exec":
                threading.Thread(target=self.run_job, args=(task,), daemon=True).start()
            elif t == "kill":
                self.kill(task["job"], "killed")
            elif t == "read_file":
                self.reply(task, self.read_file(task))
            elif t == "write_file":
                self.reply(task, self.write_file(task))
            elif t == "update":
                self.update(task)
            elif t in ("fetch", "upload", "self_update"):
                # transfers can take a while: don't block the poll loop
                threading.Thread(target=self.transfer, args=(task,), daemon=True).start()
            else:
                self.reply(task, error="unknown task type %r" % t)
        except Exception as e:
            log("ERROR %s: %s" % (t, e))
            self.reply(task, error="%s: %s" % (type(e).__name__, e))

    def reply(self, task, data=None, error=None):
        self.emit({"type": "result", "task": task["id"], "ok": error is None,
                   "data": data, "error": error})

    def run_job(self, task):
        jid = task["job"]
        cwd = os.path.expanduser(task.get("cwd") or "~")
        env = dict(os.environ)
        env.update({"PYTHONUNBUFFERED": "1", "DEBIAN_FRONTEND": "noninteractive",
                    "FLEET_JOB_ID": jid, "FLEET_MACHINE": self.name or ""})
        env.update({k: str(v) for k, v in (task.get("env") or {}).items()})
        kw = {}
        if WINDOWS:
            kw["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP
        else:
            kw["start_new_session"] = True
        try:
            p = subprocess.Popen(shell_argv(task["command"]), cwd=cwd, env=env,
                                 stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                 stderr=subprocess.STDOUT, **kw)
        except Exception as e:
            log("FAIL  %s  could not start: %s" % (jid, e))
            self.emit({"type": "started", "job": jid})
            self.emit({"type": "output", "job": jid, "data": "failed to start: %s\n" % e})
            self.emit({"type": "exit", "job": jid, "code": -1, "status": "exited",
                       "note": "failed to start"})
            return
        self.procs[jid] = p
        t0 = time.time()
        nbytes = [0]
        log("START %s  pid %d" % (jid, p.pid))
        self.emit({"type": "started", "job": jid, "pid": p.pid})
        timer = None
        if task.get("timeout"):
            timer = threading.Timer(float(task["timeout"]), self.kill, (jid, "timeout"))
            timer.daemon = True
            timer.start()
        dec = codecs.getincrementaldecoder("utf-8")(errors="replace")
        fd = p.stdout.fileno()
        while True:
            chunk = os.read(fd, 65536)
            if not chunk:
                break
            nbytes[0] += len(chunk)
            self.emit({"type": "output", "job": jid, "data": dec.decode(chunk)})
        tail = dec.decode(b"", final=True)
        if tail:
            self.emit({"type": "output", "job": jid, "data": tail})
        code = p.wait()
        if timer:
            timer.cancel()
        reason = self.kill_reason.pop(jid, None)
        self.procs.pop(jid, None)
        log("DONE  %s  %s exit=%s  %.1fs  %d bytes output" % (
            jid, reason or "exited", code, time.time() - t0, nbytes[0]))
        self.emit({"type": "exit", "job": jid, "code": code, "status": reason or "exited",
                   "note": "timeout after %ss" % task["timeout"] if reason == "timeout" else None})

    def kill(self, jid, reason):
        p = self.procs.get(jid)
        if not p or p.poll() is not None:
            return
        self.kill_reason[jid] = reason
        if WINDOWS:
            subprocess.run(["taskkill", "/T", "/F", "/PID", str(p.pid)], capture_output=True)
            return
        try:
            os.killpg(p.pid, signal.SIGTERM)
        except ProcessLookupError:
            return

        def hard():
            if p.poll() is None:
                try:
                    os.killpg(p.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
        threading.Timer(5, hard).start()

    def read_file(self, task):
        path = os.path.abspath(os.path.expanduser(task["path"]))
        size = os.path.getsize(path)
        mx = int(task.get("max_bytes") or 1000000)
        with open(path, "rb") as f:
            data = f.read(mx)
        return {"path": path, "size": size, "truncated": size > mx,
                "b64": base64.b64encode(data).decode()}

    def write_file(self, task):
        path = os.path.abspath(os.path.expanduser(task["path"]))
        d = os.path.dirname(path)
        if d:
            os.makedirs(d, exist_ok=True)
        data = base64.b64decode(task["b64"])
        with open(path, "ab" if task.get("append") else "wb") as f:
            f.write(data)
        if task.get("mode"):
            os.chmod(path, int(str(task["mode"]), 8))
        return {"path": path, "size": len(data)}

    # ---- transfers (direct HTTP to the hub, never through Claude) ---- #
    def _download(self, blob, out_path):
        req = urllib.request.Request(self.client.url + "/agent/blob/" + blob,
                                     headers={"Authorization": "Bearer " + self.client.token})
        n = 0
        with urllib.request.urlopen(req, timeout=120, context=self.client.ctx) as r, \
                open(out_path, "wb") as f:
            while True:
                chunk = r.read(1024 * 1024)
                if not chunk:
                    break
                f.write(chunk)
                n += len(chunk)
        return n

    def transfer(self, task):
        t = task["type"]
        try:
            if t == "fetch":
                data = self.fetch(task)
            elif t == "upload":
                data = self.upload(task)
            else:
                return self.self_update(task)
            log("DONE  %s %s  %d bytes  %.1fs" % (t, data.get("path") or data.get("name"),
                                                 data["bytes"], data["seconds"]))
            self.reply(task, data)
        except Exception as e:
            log("ERROR %s: %s" % (t, e))
            self.reply(task, error="%s: %s" % (type(e).__name__, e))

    def fetch(self, task):
        t0 = time.time()
        dest = os.path.abspath(os.path.expanduser(task["dest"]))
        os.makedirs(dest, exist_ok=True)
        fd, tmp = tempfile.mkstemp(dir=dest, prefix=".fleet-", suffix=".part")
        os.close(fd)
        try:
            n = self._download(task["blob"], tmp)
            target = os.path.join(dest, task["name"])
            if task["kind"] == "tar":
                safe_extract(tmp, dest)
            else:
                os.replace(tmp, target)
        finally:
            if os.path.exists(tmp):
                os.remove(tmp)
        return {"path": target, "bytes": n, "seconds": round(time.time() - t0, 1)}

    def upload(self, task):
        t0 = time.time()
        src = os.path.abspath(os.path.expanduser(task["src"]))
        if not os.path.exists(src):
            raise FileNotFoundError("No such file or folder: %s" % src)
        name = os.path.basename(src.rstrip("/\\")) or "root"
        exclude = task.get("exclude") or []
        fd, tmp = tempfile.mkstemp(prefix="fleet-up-")
        os.close(fd)
        try:
            if os.path.isfile(src):
                kind, path = "file", src
            else:
                kind, path = "tar", tmp
                with tarfile.open(tmp, "w:gz", compresslevel=6) as tar:
                    tar.add(src, arcname=name,
                            filter=lambda ti: None if excluded(ti.name, exclude) else ti)
            size = os.path.getsize(path)
            with open(path, "rb") as f:
                req = urllib.request.Request(
                    self.client.url + "/agent/upload/" + task["blob"], data=f, method="POST",
                    headers={"Authorization": "Bearer " + self.client.token,
                             "Content-Type": "application/octet-stream",
                             "Content-Length": str(size)})
                with urllib.request.urlopen(req, timeout=300, context=self.client.ctx) as r:
                    r.read()
        finally:
            os.remove(tmp)
        return {"kind": kind, "name": name, "bytes": size, "seconds": round(time.time() - t0, 1)}

    def self_update(self, task):
        fd, tmp = tempfile.mkstemp(prefix="fleet-update-", suffix=".tar.gz")
        os.close(fd)
        try:
            self._download(task["blob"], tmp)
            stage = tempfile.mkdtemp(prefix="fleet-update-")
            safe_extract(tmp, stage)
            new = os.path.join(stage, "fleet_agent.py")
            if not os.path.isfile(new):
                raise RuntimeError("update bundle has no fleet_agent.py")
            with open(new, encoding="utf-8") as fh:
                compile(fh.read(), new, "exec")      # refuse a broken update
            for f in os.listdir(stage):
                if os.path.isfile(os.path.join(stage, f)):
                    shutil.copyfile(os.path.join(stage, f), os.path.join(AGENT_DIR, f))
            shutil.rmtree(stage, ignore_errors=True)
        except Exception as e:
            log("ERROR self_update: %s" % e)
            return self.reply(task, error="%s: %s" % (type(e).__name__, e))
        finally:
            os.remove(tmp)
        running = sum(1 for p in self.procs.values() if p.poll() is None)
        msg = ("updated files; restarting now" if not running else
               "updated files; restart deferred until %d running job(s) finish" % running)
        log("SELF-UPDATE " + msg)
        self.reply(task, data=msg)
        time.sleep(2)  # let the reply go out
        self.restart()

    def update(self, task):
        if not os.path.isdir(os.path.join(AGENT_DIR, ".git")):
            return self.reply(task, error="agent dir %s is not a git checkout" % AGENT_DIR)
        r = subprocess.run(["git", "-C", AGENT_DIR, "pull", "--ff-only"],
                           capture_output=True, text=True, timeout=90)
        msg = (r.stdout + r.stderr).strip()
        if r.returncode != 0:
            return self.reply(task, error="git pull failed: " + msg)
        self.reply(task, data=msg + " - restarting agent")
        time.sleep(2)  # let the sender flush the reply
        self.restart()

    def restart(self):
        # Never kill running experiments: wait until every job has finished.
        if any(p.poll() is None for p in self.procs.values()):
            log("jobs still running; restart deferred until they finish")
            threading.Thread(target=self._restart_when_idle, daemon=True).start()
            return
        self._do_restart()

    def _restart_when_idle(self):
        while any(p.poll() is None for p in self.procs.values()):
            time.sleep(2)
        time.sleep(3)   # let final job events reach the hub
        self._do_restart()

    def _do_restart(self):
        log("restarting agent")
        if WINDOWS:
            # Restart through the Scheduled Task from a helper that is not our child
            # (created via WMI), so it survives this process being stopped.
            script = os.path.join(STATE, "restart-agent.ps1")
            with open(script, "w") as f:
                f.write(RESTART_PS1)
            task = self.cfg.get("task_name") or "claude-fleet"   # pre-1.4 installs
            helper = ('powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden '
                      '-File "%s" -TaskName "%s" -AgentPath "%s"'
                      % (script, task, os.path.join(AGENT_DIR, "fleet_agent.py")))
            ps = ("$r = Invoke-CimMethod -ClassName Win32_Process -MethodName Create "
                  "-Arguments @{CommandLine='%s'}; exit $r.ReturnValue" % helper.replace("'", "''"))
            r = subprocess.run(["powershell.exe", "-NoProfile", "-Command", ps],
                               capture_output=True, text=True)
            if r.returncode == 0:
                return          # helper will stop and restart us
            log("WMI restart helper failed (%s); re-executing directly" % r.stdout.strip())
        os.execv(sys.executable, [sys.executable, os.path.join(AGENT_DIR, "fleet_agent.py"), "run"])

    # ---- main loop ---- #
    def hello(self):
        r = self.client.post("/agent/hello", {
            "machine_id": self.mid,
            "fingerprint": "" if self.cfg.get("no_adopt") else fingerprint(),
            # identity never yet acknowledged by a hub -> hub may re-attach an old record
            "new_identity": not identity().get("announced"),
            "requested_name": self.cfg.get("name") or socket.gethostname(),
            "info": system_info(),
            "running_jobs": [j for j, p in self.procs.items() if p.poll() is None],
        })
        ident = identity()
        if not ident.get("announced"):
            ident["announced"] = True
            write_json(IDENTITY, ident)
        if r.get("name") != self.name:
            log("registered with hub as '%s'" % r.get("name"))
        self.name = r.get("name")

    def run(self):
        log("claude-fleet agent %s, machine id %s, hub %s" % (VERSION, self.mid, self.cfg["hub"]))
        threading.Thread(target=self.sender, daemon=True).start()
        if self.cfg.get("keep_awake", True) and os.environ.get("FLEET_KEEP_AWAKE") != "0":
            KeepAwake(lambda: any(p.poll() is None for p in list(self.procs.values()))).start()
        backoff = 1
        need_hello = True
        while True:
            try:
                if need_hello:
                    self.hello()
                    need_hello = False
                r = self.client.post("/agent/poll",
                                     {"machine_id": self.mid, "ack": self.seen[-200:]}, timeout=60)
                for task in r.get("tasks", []):
                    if task.get("id") in self.seen:
                        continue
                    self.seen.append(task.get("id"))
                    self.handle(task)
                del self.seen[:-500]
                backoff = 1
            except HubError as e:
                if e.status == 401:
                    log("hub rejected token - re-run install with the token printed by the hub")
                    time.sleep(60)
                else:
                    log("hub error: %s" % e)
                    time.sleep(backoff)
                need_hello = True
                backoff = min(backoff * 2, 30)
            except Exception as e:
                log("cannot reach hub (%s); retrying in %ds" % (e.__class__.__name__, backoff))
                time.sleep(backoff)
                need_hello = True
                backoff = min(backoff * 2, 30)


# --------------------------------------------------------------------------- #
# CLI
# --------------------------------------------------------------------------- #

def load_cfg():
    cfg = read_json(CONFIG)
    if not cfg or not cfg.get("hub") or not cfg.get("token"):
        sys.exit("Not configured. Run: fleet_agent.py configure HUB_URL TOKEN")
    return cfg


def main():
    ap = argparse.ArgumentParser(description="claude-fleet agent")
    sub = ap.add_subparsers(dest="cmd")
    c = sub.add_parser("configure")
    c.add_argument("hub")
    c.add_argument("token")
    c.add_argument("--name")
    c.add_argument("--task-name", help="Windows Scheduled Task the installer created")
    sub.add_parser("check")
    sub.add_parser("run")
    sub.add_parser("status")
    w = sub.add_parser("watch", help="show the agent's activity log live in this terminal")
    w.add_argument("-n", type=int, default=30, help="lines of history to show first")
    sub.add_parser("reset-identity", help="give this machine a brand-new identity (e.g. after cloning a VM)")
    a = ap.parse_args()

    if a.cmd == "configure":
        hub = a.hub if "://" in a.hub else "http://" + a.hub
        cfg = read_json(CONFIG, {}) or {}
        cfg.update({"hub": hub.rstrip("/"), "token": a.token})
        if a.name:
            cfg["name"] = a.name
        if a.task_name:
            cfg["task_name"] = a.task_name
        write_json(CONFIG, cfg)
        identity()
        print("Saved %s" % CONFIG)
    elif a.cmd == "check":
        cfg = load_cfg()
        ag = Agent(cfg)
        try:
            ag.hello()
        except HubError as e:
            sys.exit("Hub answered with an error: %s" % e)
        except Exception as e:
            sys.exit("Cannot reach hub at %s: %s" % (cfg["hub"], e))
        print("OK - hub reachable, this machine is named '%s'" % ag.name)
    elif a.cmd == "run":
        Agent(load_cfg()).run()
    elif a.cmd == "watch":
        watch(a.n)
    elif a.cmd == "reset-identity":
        try:
            os.remove(IDENTITY)
        except FileNotFoundError:
            pass
        cfg = read_json(CONFIG, {}) or {}
        cfg["no_adopt"] = True
        write_json(CONFIG, cfg)
        print("New machine id: %s (restart the agent)" % identity()["machine_id"])
    elif a.cmd == "status":
        cfg = read_json(CONFIG, {}) or {}
        print(json.dumps({"config": {k: (v if k != "token" else "***") for k, v in cfg.items()},
                          "identity": read_json(IDENTITY), "state_dir": STATE,
                          "info": system_info()}, indent=2))
    else:
        ap.print_help()


if __name__ == "__main__":
    main()
