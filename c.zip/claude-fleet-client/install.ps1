# claude-fleet client installer (Windows, PowerShell).
#
#   .\install.ps1 HUB_URL TOKEN [-Name NAME]
#
# If scripts are blocked:  powershell -ExecutionPolicy Bypass -File .\install.ps1 HUB_URL TOKEN
# Registers a Scheduled Task (claude-fleet-<your username>) that starts the agent at logon
# and restarts it if it dies. Task names are shared by every account on a machine, so the
# name includes your username to avoid clashing with other people's installs.
param(
  [Parameter(Mandatory=$true, Position=0)][string]$Hub,
  [Parameter(Mandatory=$true, Position=1)][string]$Token,
  [string]$Name = ""
)
$ErrorActionPreference = "Stop"
$Dir = Split-Path -Parent $MyInvocation.MyCommand.Path
$Agent = Join-Path $Dir "fleet_agent.py"

$py = $null
foreach ($c in @("py", "python", "python3")) {
  $cmd = Get-Command $c -ErrorAction SilentlyContinue
  if ($cmd -and $cmd.Source -notlike "*WindowsApps*") { $py = $cmd.Source; break }
}
if (-not $py) { throw "Python 3.8+ is required. Install from https://www.python.org/downloads/ (tick 'Add to PATH') and re-run." }
$pyArgs = @()
if ((Split-Path $py -Leaf) -eq "py.exe") { $pyArgs = @("-3") }

$TaskName = "claude-fleet-$env:USERNAME"
$cfgFile = Join-Path $env:USERPROFILE ".claude-fleet\config.json"
$backup = $null
if (Test-Path $cfgFile) { $backup = Get-Content $cfgFile -Raw }

$cfg = @($pyArgs + @($Agent, "configure", $Hub, $Token, "--task-name", $TaskName))
if ($Name) { $cfg += @("--name", $Name) }
& $py @cfg
& $py @($pyArgs + @($Agent, "check"))
if ($LASTEXITCODE -ne 0) {
  # keep the previous working settings instead of the ones that just failed
  if ($backup) { Set-Content -Path $cfgFile -Value $backup -NoNewline }
  throw "Hub check failed (see the line above for why). Previous settings were kept."
}

# pythonw runs without a console window
$pyw = Join-Path (Split-Path $py) "pythonw.exe"
if (-not (Test-Path $pyw)) { $pyw = $py }
$argline = (($pyArgs + @("`"$Agent`"", "run")) -join " ")

$action = New-ScheduledTaskAction -Execute $pyw -Argument $argline -WorkingDirectory $env:USERPROFILE
$trigger = New-ScheduledTaskTrigger -AtLogOn -User $env:USERNAME
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries `
  -RestartCount 999 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit ([TimeSpan]::Zero)
# Stop any agent of ours that is already running (e.g. from an older install).
Get-CimInstance Win32_Process | Where-Object {
  $_.CommandLine -and $_.CommandLine.IndexOf($Agent, [StringComparison]::OrdinalIgnoreCase) -ge 0 -and $_.CommandLine -match '\s+run\s*$' } |
  ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }

# Older versions used the plain name "claude-fleet". Remove it only if it is ours.
$old = Get-ScheduledTask -TaskName "claude-fleet" -ErrorAction SilentlyContinue
if ($old -and ($old.Actions | Where-Object { $_.Arguments -and $_.Arguments.IndexOf($Agent, [StringComparison]::OrdinalIgnoreCase) -ge 0 })) {
  Unregister-ScheduledTask -TaskName "claude-fleet" -Confirm:$false -ErrorAction SilentlyContinue
}

Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction SilentlyContinue
Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger $trigger -Settings $settings | Out-Null
Start-ScheduledTask -TaskName $TaskName
Write-Host "Watch commands arrive live with:  python `"$Agent`" watch"
Write-Host "Done. Agent runs at logon (Scheduled Task '$TaskName')."
Write-Host "Stop: Stop-ScheduledTask $TaskName   Remove: Unregister-ScheduledTask $TaskName"
