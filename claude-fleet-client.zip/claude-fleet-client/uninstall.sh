#!/usr/bin/env bash
# Remove the claude-fleet service from this machine.
#   ./uninstall.sh            stop + remove service (keeps identity, so the name survives a reinstall)
#   ./uninstall.sh --purge    also delete ~/.claude-fleet (identity + config)
set -u
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
AGENT="$DIR/fleet_agent.py"
LABEL="com.claude-fleet.agent"

if [ "$(uname)" = Darwin ]; then
  launchctl bootout "gui/$(id -u)/$LABEL" 2>/dev/null || launchctl unload "$HOME/Library/LaunchAgents/$LABEL.plist" 2>/dev/null
  rm -f "$HOME/Library/LaunchAgents/$LABEL.plist"
fi
if command -v systemctl >/dev/null 2>&1; then
  if [ "$(id -u)" = 0 ] && [ -f /etc/systemd/system/claude-fleet.service ]; then
    systemctl disable --now claude-fleet.service 2>/dev/null
    rm -f /etc/systemd/system/claude-fleet.service; systemctl daemon-reload
  fi
  if [ -f "$HOME/.config/systemd/user/claude-fleet.service" ]; then
    systemctl --user disable --now claude-fleet.service 2>/dev/null
    rm -f "$HOME/.config/systemd/user/claude-fleet.service"; systemctl --user daemon-reload 2>/dev/null
  fi
fi
if command -v crontab >/dev/null 2>&1; then
  ( crontab -l 2>/dev/null | grep -vF "$AGENT run" ) | crontab - 2>/dev/null
fi
pkill -f "$AGENT run" 2>/dev/null
[ -f "/etc/sudoers.d/claude-fleet-$(id -un)" ] && sudo rm -f "/etc/sudoers.d/claude-fleet-$(id -un)"
[ "${1:-}" = "--purge" ] && rm -rf "$HOME/.claude-fleet" && echo "Deleted ~/.claude-fleet"
echo "claude-fleet agent removed."
