# claude-fleet client

Lets Claude (running on your parent computer) run commands on this machine.
Pure Python standard library — nothing to `pip install`. Needs Python 3.8+.

## Install (one command)

The hub prints the exact line with your URL and token when it starts.

```bash
git clone https://github.com/<you>/claude-fleet-client.git ~/claude-fleet
cd ~/claude-fleet
./install.sh http://PARENT_IP:8765 TOKEN
```

Options:

| flag | what it does |
|---|---|
| `--name NAME` | Name for this machine (default: hostname). Only used the first time it registers; after that the hub owns the name. |
| `--allow-sudo` | Gives the agent's user passwordless sudo so Claude can `sudo apt install …`. Asks for your password once. |
| `--no-service` | Configure only; run it yourself with `python3 fleet_agent.py run`. |

Run as root (`sudo ./install.sh …`) instead if you want the agent itself to be root.

Windows (PowerShell, Python from python.org on PATH):

```powershell
powershell -ExecutionPolicy Bypass -File .\install.ps1 http://PARENT_IP:8765 TOKEN
```

## What gets installed

- **Linux**: a systemd service (user service with linger, or a system service when run as root). Starts at boot, restarts if it dies. Falls back to `nohup` + an `@reboot` crontab line where systemd isn't available.
- **macOS**: a LaunchAgent (`com.claude-fleet.agent`).
- **Windows**: a Scheduled Task named `claude-fleet` that runs at logon.

The service runs `fleet_agent.py` from this folder, so leave the clone where it is.

## Identity

`~/.claude-fleet/identity.json` holds a permanent machine id (outside the repo, so deleting and re-cloning doesn't change anything). The hub maps that id to a name forever. If the identity file is ever lost, the hub recognizes the same hardware + user and gives back the old name.

**Cloned a VM after installing?** Run `python3 fleet_agent.py reset-identity` on the clone and restart the agent, otherwise both copies share one identity.

## Useful commands

```bash
python3 fleet_agent.py status     # identity, config, detected hardware
python3 fleet_agent.py check      # can I reach the hub?
journalctl --user -u claude-fleet -f    # logs (Linux user service)
./uninstall.sh                    # remove service (keeps identity → same name on reinstall)
./uninstall.sh --purge            # also delete identity + config
```

Updating: push to this repo, then ask Claude to run `update_agent` (it does `git pull` and restarts each agent, waiting for running jobs to finish first).

## Security

Anyone with the token can run any command on this machine as the agent's user. Keep the token out of the repo (it is never stored here — only in `~/.claude-fleet/config.json`, mode 600). Over untrusted networks, put the hub behind Tailscale/WireGuard or give it a TLS cert (see the parent README).
