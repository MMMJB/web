#!/usr/bin/env bash
# claude-fleet client installer (Linux / macOS).
#
#   ./install.sh HUB_URL TOKEN [--name NAME] [--allow-sudo] [--no-service]
#
# HUB_URL and TOKEN are printed by the hub when it starts.
#   --name NAME     name for this machine (default: hostname). Only used the first
#                   time the machine registers; afterwards the hub keeps the name.
#   --allow-sudo    let the agent's user run sudo without a password, so Claude can
#                   install system packages (asks for your sudo password once).
#   --no-service    just configure; don't install a background service.
set -euo pipefail

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
AGENT="$DIR/fleet_agent.py"
STATE="$HOME/.claude-fleet"
LABEL="com.claude-fleet.agent"

usage() { sed -n '2,13p' "$0" | sed 's/^# \{0,1\}//'; exit 1; }

HUB="" TOKEN="" NAME="" ALLOW_SUDO=0 SERVICE=1
while [ $# -gt 0 ]; do
  case "$1" in
    --name) NAME="$2"; shift 2 ;;
    --allow-sudo) ALLOW_SUDO=1; shift ;;
    --no-service) SERVICE=0; shift ;;
    -h|--help) usage ;;
    *) if [ -z "$HUB" ]; then HUB="$1"; elif [ -z "$TOKEN" ]; then TOKEN="$1"; else usage; fi; shift ;;
  esac
done
[ -n "$HUB" ] && [ -n "$TOKEN" ] || usage

# ---- python ---------------------------------------------------------------
PY=""
for c in python3 python; do
  if command -v "$c" >/dev/null 2>&1 && "$c" -c 'import sys; sys.exit(sys.version_info < (3,8))' 2>/dev/null; then
    PY="$(command -v "$c")"; break
  fi
done
if [ -z "$PY" ]; then
  echo "Python 3.8+ is required. Install it (e.g. 'sudo apt install python3' or 'brew install python') and re-run." >&2
  exit 1
fi
echo "Using $PY ($("$PY" -V 2>&1))"

# ---- configure + verify ---------------------------------------------------
ARGS=(configure "$HUB" "$TOKEN"); [ -n "$NAME" ] && ARGS+=(--name "$NAME")
CFG="$STATE/config.json"
[ -f "$CFG" ] && cp "$CFG" "$CFG.bak"
"$PY" "$AGENT" "${ARGS[@]}"
if ! "$PY" "$AGENT" check; then
  [ -f "$CFG.bak" ] && mv "$CFG.bak" "$CFG"   # keep the previous working config
  echo "Install aborted: fix the hub URL/token (copy them from the hub's startup banner)." >&2
  exit 1
fi
rm -f "$CFG.bak"

# ---- optional passwordless sudo -------------------------------------------
if [ "$ALLOW_SUDO" = 1 ] && [ "$(id -u)" != 0 ]; then
  F="/etc/sudoers.d/claude-fleet-$(id -un)"
  echo "Granting passwordless sudo to $(id -un) via $F"
  echo "$(id -un) ALL=(ALL) NOPASSWD: ALL" | sudo tee "$F" >/dev/null
  sudo chmod 440 "$F"
  sudo visudo -cf "$F" >/dev/null || { sudo rm -f "$F"; echo "sudoers check failed; skipped" >&2; }
fi

[ "$SERVICE" = 1 ] || { echo "Configured. Run manually with: $PY $AGENT run"; exit 0; }

# ---- service --------------------------------------------------------------
stop_fallback() { pkill -f "$AGENT run" 2>/dev/null || true; }

install_systemd_system() {
  cat > /etc/systemd/system/claude-fleet.service <<EOF
[Unit]
Description=claude-fleet agent
After=network-online.target
Wants=network-online.target

[Service]
ExecStart=$PY $AGENT run
Environment=HOME=$HOME
WorkingDirectory=$HOME
Restart=always
RestartSec=5
KillMode=process

[Install]
WantedBy=multi-user.target
EOF
  systemctl daemon-reload
  systemctl enable claude-fleet.service >/dev/null
  systemctl restart claude-fleet.service
  echo "Installed system service. Logs: journalctl -u claude-fleet -f"
}

install_systemd_user() {
  mkdir -p "$HOME/.config/systemd/user"
  cat > "$HOME/.config/systemd/user/claude-fleet.service" <<EOF
[Unit]
Description=claude-fleet agent
After=network-online.target

[Service]
ExecStart=$PY $AGENT run
Restart=always
RestartSec=5
KillMode=process

[Install]
WantedBy=default.target
EOF
  systemctl --user daemon-reload
  systemctl --user enable claude-fleet.service >/dev/null
  systemctl --user restart claude-fleet.service
  # keep running after logout / start at boot without login
  if ! loginctl show-user "$(id -un)" 2>/dev/null | grep -q '^Linger=yes'; then
    loginctl enable-linger "$(id -un)" 2>/dev/null || sudo loginctl enable-linger "$(id -un)" 2>/dev/null || \
      echo "WARNING: couldn't enable linger; the agent will stop when you log out. Run: sudo loginctl enable-linger $(id -un)" >&2
  fi
  echo "Installed user service. Logs: journalctl --user -u claude-fleet -f"
}

install_launchd() {
  PL="$HOME/Library/LaunchAgents/$LABEL.plist"
  mkdir -p "$HOME/Library/LaunchAgents" "$STATE"
  cat > "$PL" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>Label</key><string>$LABEL</string>
  <key>ProgramArguments</key><array><string>$PY</string><string>$AGENT</string><string>run</string></array>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key><true/>
  <key>AbandonProcessGroup</key><true/>
  <key>WorkingDirectory</key><string>$HOME</string>
  <key>StandardOutPath</key><string>$STATE/agent.log</string>
  <key>StandardErrorPath</key><string>$STATE/agent.log</string>
</dict></plist>
EOF
  launchctl bootout "gui/$(id -u)/$LABEL" 2>/dev/null || launchctl unload "$PL" 2>/dev/null || true
  launchctl bootstrap "gui/$(id -u)" "$PL" 2>/dev/null || launchctl load -w "$PL"
  echo "Installed LaunchAgent. Logs: $STATE/agent.log"
}

install_fallback() {
  mkdir -p "$STATE"
  stop_fallback
  nohup "$PY" "$AGENT" run >>"$STATE/agent.log" 2>&1 &
  LINE="@reboot $PY $AGENT run >>$STATE/agent.log 2>&1"
  if command -v crontab >/dev/null 2>&1; then
    ( crontab -l 2>/dev/null | grep -vF "$AGENT run"; echo "$LINE" ) | crontab - || true
  fi
  echo "Started agent with nohup (+ @reboot crontab). Logs: $STATE/agent.log"
}

stop_fallback
if [ "$(uname)" = Darwin ]; then
  install_launchd
elif command -v systemctl >/dev/null 2>&1 && [ -d /run/systemd/system ]; then
  if [ "$(id -u)" = 0 ]; then install_systemd_system
  elif systemctl --user show-environment >/dev/null 2>&1; then install_systemd_user
  else
    echo "No systemd user session here (common over plain SSH); using fallback."
    install_fallback
  fi
else
  install_fallback
fi

sleep 2
echo
echo "Done. This machine is connected to the hub; Claude can see it with list_machines."
