# claude-fleet client installer (Windows, PowerShell).
#
#   .\install.ps1 HUB_URL TOKEN [-Name NAME]
#
# If scripts are blocked:  powershell -ExecutionPolicy Bypass -File .\install.ps1 HUB_URL TOKEN
# Registers a Scheduled Task that starts the agent at logon and restarts it if it dies.
param(
  [Parameter(Mandatory=$true, Position=0)][string]$Hub,
  [Parameter(Mandatory=$true, Position=1)][string]$Token,
  [string]$Name = ""
)
$ErrorActionPreference = "Stop"
$Dir = Split-Path -Parent $MyInvocation.MyCommand.Path
$Agent = Join-Path $Dir "fleet_agent.py"

$py = $null
foreach ($c in @("py", "python", "python3")) {
  $cmd = Get-Command $c -ErrorAction SilentlyContinue
  if ($cmd -and $cmd.Source -notlike "*WindowsApps*") { $py = $cmd.Source; break }
}
if (-not $py) { throw "Python 3.8+ is required. Install from https://www.python.org/downloads/ (tick 'Add to PATH') and re-run." }
$pyArgs = @()
if ((Split-Path $py -Leaf) -eq "py.exe") { $pyArgs = @("-3") }

$cfg = @($pyArgs + @($Agent, "configure", $Hub, $Token))
if ($Name) { $cfg += @("--name", $Name) }
& $py @cfg
& $py @($pyArgs + @($Agent, "check"))
if ($LASTEXITCODE -ne 0) { throw "Hub check failed." }

# pythonw runs without a console window
$pyw = Join-Path (Split-Path $py) "pythonw.exe"
if (-not (Test-Path $pyw)) { $pyw = $py }
$argline = (($pyArgs + @("`"$Agent`"", "run")) -join " ")

$action = New-ScheduledTaskAction -Execute $pyw -Argument $argline -WorkingDirectory $env:USERPROFILE
$trigger = New-ScheduledTaskTrigger -AtLogOn -User $env:USERNAME
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries `
  -RestartCount 999 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit ([TimeSpan]::Zero)
Unregister-ScheduledTask -TaskName "claude-fleet" -Confirm:$false -ErrorAction SilentlyContinue
Register-ScheduledTask -TaskName "claude-fleet" -Action $action -Trigger $trigger -Settings $settings | Out-Null
Start-ScheduledTask -TaskName "claude-fleet"
Write-Host "Done. Agent runs at logon (Scheduled Task 'claude-fleet'). Remove with: Unregister-ScheduledTask claude-fleet"
